.. simple_messanger documentation master file, created by
   sphinx-quickstart on Tue Jan  4 00:23:19 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to simple_messanger's documentation!
============================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:
   
   client
   server
   common
   logs


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
